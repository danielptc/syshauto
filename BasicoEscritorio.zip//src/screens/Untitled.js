import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import MaterialCommunityIconsIcon from "react-native-vector-icons/MaterialCommunityIcons";

export default class Untitled extends Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.Temperatura}>
          <View
            style={[
              styles.row,
              {
                marginTop: 23.15,
                marginLeft: 40.67,
                marginRight: 45.43,
                height: 73
              }
            ]}
          >
            <MaterialCommunityIconsIcon
              name="thermometer-lines"
              style={styles.Termometro}
            />
            <Text style={styles.ValorTemperatura}>28</Text>
            <MaterialCommunityIconsIcon
              name="temperature-celsius"
              style={styles.graus}
            />
          </View>
          <View
            style={[
              styles.row,
              {
                marginTop: 35.71,
                marginLeft: 30.67,
                marginRight: 45.43,
                height: 70
              }
            ]}
          >
            <MaterialCommunityIconsIcon
              name="power"
              style={styles.Liga_desliga}
            />
            <MaterialCommunityIconsIcon
              name="plus-circle"
              style={styles.Aumentar}
            />
            <MaterialCommunityIconsIcon
              name="minus-circle"
              style={styles.diminuir}
            />
          </View>
        </View>
        <View
          style={[
            styles.stack,
            {
              marginTop: 16.64,
              marginLeft: 26.12,
              height: 248.18,
              width: 344.72
            }
          ]}
        >
          <View style={styles.Energia}>
            <Text style={styles.Iluminacao}>Ilumina��o</Text>
            <View
              style={[
                styles.row,
                {
                  marginTop: 7.16,
                  marginLeft: 61.14,
                  marginRight: 31.75,
                  height: 64.26
                }
              ]}
            >
              <Text style={styles.StatusLampada}>Ligada</Text>
              <Image
                source={require("../assets/images/lampada_Amarelo.png")}
                resizeMode="contain"
                style={styles.lampada}
              />
            </View>
          </View>
          <View style={styles.rect}>
            <Text style={styles.Tomada01}>Tomada 01</Text>
            <View
              style={[
                styles.row,
                {
                  marginTop: 15.11,
                  marginLeft: 61.14,
                  marginRight: 72.5,
                  height: 43.89
                }
              ]}
            >
              <Text style={styles.StatusTomada01}>Ligada</Text>
              <Image
                source={require("../assets/images/energia_w.png")}
                resizeMode="contain"
                style={styles.Ligada}
              />
            </View>
          </View>
        </View>
        <View style={styles.rect2}>
          <Text style={styles.Tomada02}>Tomada 02</Text>
          <View
            style={[
              styles.row,
              {
                marginTop: 9.83,
                marginLeft: 61.97,
                marginRight: 42.93,
                height: 46.27
              }
            ]}
          >
            <Text style={styles.StatusTomada02}>Desligada</Text>
            <Image
              source={require("../assets/images/apagar_w.png")}
              resizeMode="contain"
              style={styles.Deligada}
            />
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,1)",
    opacity: 1,
    borderRadius: 6
  },
  Temperatura: {
    width: 345,
    height: 239,
    backgroundColor: "rgba(0,0,0,1)",
    borderRadius: 31,
    borderColor: "rgba(255,255,255,1)",
    borderWidth: 4,
    marginTop: 38,
    marginLeft: 29
  },
  row: {
    flexDirection: "row"
  },
  Termometro: {
    color: "rgba(80,227,194,1)",
    fontSize: 60,
    height: 60,
    width: 60,
    marginLeft: -0.17,
    marginTop: 12.93
  },
  ValorTemperatura: {
    color: "rgba(155,155,155,1)",
    fontSize: 66,
    marginLeft: 32,
    marginTop: -0.07
  },
  graus: {
    color: "grey",
    fontSize: 70,
    height: 70,
    width: 70,
    marginLeft: 22.87,
    marginTop: 2.93
  },
  Liga_desliga: {
    color: "rgba(36,244,0,1)",
    fontSize: 70,
    height: 70,
    width: 70,
    marginLeft: -0.17,
    marginTop: 0.22
  },
  Aumentar: {
    color: "rgba(255,13,13,1)",
    fontSize: 70,
    height: 70,
    width: 70,
    marginLeft: 21,
    marginTop: 0.22
  },
  diminuir: {
    color: "rgba(46,49,205,1)",
    fontSize: 70,
    height: 70,
    width: 70,
    marginLeft: 38,
    marginTop: 0.22
  },
  stack: {
    position: "relative"
  },
  Energia: {
    top: 0.13,
    left: -0.12,
    width: 345,
    height: 124,
    backgroundColor: "rgba(0,0,0,1)",
    position: "absolute",
    borderRadius: 31,
    borderColor: "rgba(255,255,255,1)",
    borderWidth: 4
  },
  Iluminacao: {
    color: "rgba(255,255,255,1)",
    fontSize: 30,
    marginTop: 12.13,
    marginLeft: 98.88
  },
  StatusLampada: {
    color: "rgba(255,255,255,1)",
    fontSize: 28,
    marginLeft: -0.26,
    marginTop: 18.84
  },
  lampada: {
    width: 138,
    height: 64,
    marginLeft: 30.17,
    marginTop: -0.16
  },
  rect: {
    top: 124.13,
    left: -0.12,
    width: 345,
    height: 124,
    backgroundColor: "rgba(0,0,0,1)",
    position: "absolute",
    borderRadius: 31,
    borderColor: "rgba(255,255,255,1)",
    borderWidth: 4
  },
  Tomada01: {
    color: "rgba(255,255,255,1)",
    fontSize: 30,
    marginTop: 23.04,
    marginLeft: 101.88
  },
  StatusTomada01: {
    color: "rgba(255,255,255,1)",
    fontSize: 28,
    marginLeft: -0.26,
    marginTop: 6.89
  },
  Ligada: {
    width: 63,
    height: 44,
    marginLeft: 65.17,
    marginTop: -0.11
  },
  rect2: {
    width: 345,
    height: 124,
    backgroundColor: "rgba(0,0,0,1)",
    borderRadius: 31,
    borderColor: "rgba(255,255,255,1)",
    borderWidth: 4,
    marginTop: 4.95,
    marginLeft: 26
  },
  Tomada02: {
    color: "rgba(255,255,255,1)",
    fontSize: 30,
    marginTop: 9.77,
    marginLeft: 103
  },
  StatusTomada02: {
    color: "rgba(255,255,255,1)",
    fontSize: 28,
    marginLeft: 0.03,
    marginTop: 12.17
  },
  Deligada: {
    width: 88,
    height: 46,
    marginLeft: 28.81,
    marginTop: 0.17
  }
});
