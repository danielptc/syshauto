import React, { Component } from "react";
import {
  StyleSheet,
  View,
  Image,
  ImageBackground,
  TouchableOpacity
} from "react-native";

export default class Untitled extends Component {
  render() {
    return (
      <View style={styles.container}>
        <ImageBackground
          source={require("../assets/images/planta.jpg")}
          resizeMode="contain"
          style={styles.image}
        >
          <View
            style={[
              styles.stack,
              {
                marginTop: 57.82,
                marginLeft: 16.28,
                height: 278.34,
                width: 380.67
              }
            ]}
          >
            <ImageBackground
              source={require("../assets/images/amarelo22.jpg")}
              resizeMode="contain"
              style={styles.Sala}
            >
              <TouchableOpacity style={styles.BtnSala} />
            </ImageBackground>
            <ImageBackground
              source={require("../assets/images/amarelo23.jpg")}
              resizeMode="contain"
              style={styles.Dormi01}
            >
              <TouchableOpacity style={styles.BtnDorm01} />
            </ImageBackground>
          </View>
          <View
            style={[
              styles.row,
              {
                marginTop: 11.56,
                marginLeft: 16.28,
                marginRight: 13.21,
                height: 239.26
              }
            ]}
          >
            <View
              style={[
                styles.stack,
                {
                  height: 148.25,
                  width: 183.44
                }
              ]}
            >
              <Image
                source={require("../assets/images/amarelo2.jpg")}
                resizeMode="contain"
                style={styles.Cozinha}
              />
              <TouchableOpacity style={styles.BtnCozinha} />
            </View>
            <ImageBackground
              source={require("../assets/images/amarelo1.jpg")}
              resizeMode="contain"
              style={styles.Dormi02}
            >
              <TouchableOpacity style={styles.BtnDorm02} />
            </ImageBackground>
          </View>
        </ImageBackground>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,1)",
    opacity: 1
  },
  image: {
    width: 397,
    height: 656
  },
  stack: {
    position: "relative"
  },
  Sala: {
    top: 0.18,
    left: -0.28,
    width: 200,
    height: 278,
    position: "absolute",
    opacity: 0.5
  },
  BtnSala: {
    width: 167,
    height: 270,
    backgroundColor: "rgba(61,28,248,1)",
    opacity: 0.44,
    marginTop: 4.18,
    marginLeft: 16.72
  },
  Dormi01: {
    top: 0.18,
    left: 178.72,
    width: 202,
    height: 211,
    position: "absolute",
    opacity: 0.5
  },
  BtnDorm01: {
    width: 157,
    height: 211,
    backgroundColor: "rgba(61,28,248,1)",
    opacity: 0.44,
    marginTop: 0.18,
    marginLeft: 20.58
  },
  row: {
    flexDirection: "row"
  },
  Cozinha: {
    top: 0.28,
    left: -0.28,
    width: 182,
    height: 148,
    position: "absolute",
    opacity: 0.5
  },
  BtnCozinha: {
    top: 0.28,
    left: 12.72,
    width: 171,
    height: 148,
    backgroundColor: "rgba(61,28,248,1)",
    position: "absolute",
    opacity: 0.44
  },
  Dormi02: {
    width: 167,
    height: 152,
    opacity: 0.49,
    marginLeft: 16.28,
    marginTop: 87.28
  },
  BtnDorm02: {
    width: 157,
    height: 152,
    backgroundColor: "rgba(61,28,248,1)",
    opacity: 0.44,
    marginTop: -0.42,
    marginLeft: 1.72
  }
});
